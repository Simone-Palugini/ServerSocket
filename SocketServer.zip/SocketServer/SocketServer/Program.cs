﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace SocketServer
{
    class Program
    {
        static void Main(string[] args)
        {
            Socket listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            IPAddress iPAddress = IPAddress.Any;
            IPEndPoint iPEndPoint = new IPEndPoint(iPAddress, 23000);

            listener.Bind(iPEndPoint);

            listener.Listen(5);
            Console.WriteLine("Server in ascolto...");

            Socket client = listener.Accept();

            Console.WriteLine("Client connesso: " + client.RemoteEndPoint.ToString());

            byte[] buff = new byte[128];
            int receivedBytes = 0;
            int sendBytes = 0;
            string receivedString = "";
            string sendString = "";
            while (true)
            {
                receivedBytes = client.Receive(buff);
                receivedString = Encoding.ASCII.GetString(buff, 0, receivedBytes);
                Console.WriteLine("Client: " + receivedString);

                if (receivedString.ToUpper() == "QUIT")
                {
                    break;
                }
                else if (receivedString.ToUpper() == "CIAO")
                {
                    sendString = "Ciao a te";
                }
                else if (receivedString.ToUpper() == "COME STAI")
                {
                    sendString = "Bene";
                }
                else if (receivedString.ToUpper() == "CHE FAI")
                {
                    sendString = "Niente";
                }
                else
                {
                    sendString = "Non importa";
                }

                buff = Encoding.ASCII.GetBytes(sendString);
                client.Send(buff);
                Array.Clear(buff, 0, buff.Length);
            }

        }
    }
}
